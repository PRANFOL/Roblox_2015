module.exports = [
    {},
    {
        id: 1,
        name: "TestHat",
        price: { robux: 100, tickets: 0 },
        onsale: true,
        description: "This is a hat just for testing!",
        creator: "admin",
        category: "Hat",
        created: "6/18/2022 5:59AM PST",
        limited: false,
        limitedU: false
    }
]